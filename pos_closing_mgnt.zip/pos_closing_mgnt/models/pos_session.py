# -*- coding: utf-8 -*-
from odoo import fields, models, api
from odoo.exceptions import ValidationError



class PosSession(models.Model):

    _inherit = 'pos.session'

    @api.multi
    def action_pos_session_closing_control(self):
        result = super(PosSession, self).action_pos_session_closing_control()
        if  not self.can_be_closed:
            raise ValidationError("Impossible de fermer votre session.\nVeuillez contacter votre administrateur!!!")
        return result


    @api.multi
    def action_pos_session_open(self):
        result = super(PosSession, self).action_pos_session_open()
        self.can_be_closed = False
        return result


    @api.multi
    def open_frontend_cb(self):
        result = super(PosSession, self).open_frontend_cb()
        self.can_be_closed = False
        return result  

    #cette methode sera appelée dans le JS
    @api.model
    def set_field_can_be_closed(self, pos_session_id):
        session_obj = self.env['pos.session'].browse(pos_session_id)
        valeur = session_obj.can_be_closed = True
            


    #champ permettant de faire le check si oui ou non la session pourra être fermée
    can_be_closed = fields.Boolean(
        string='Peut être fermée ?',
        default=False,
        help="Ce champ permet de dire si oui ou non la session peut être fermée")

