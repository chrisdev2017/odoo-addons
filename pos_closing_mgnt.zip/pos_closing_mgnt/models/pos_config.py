# -*- coding: utf-8 -*-
from odoo import fields, models, api
from odoo.exceptions import ValidationError



class PosConfig(models.Model):

    _inherit = 'pos.config'

    @api.multi
    def open_ui(self):
        result = super(PosConfig, self).open_ui()

        self.current_session_id.can_be_closed = False
        return result


    @api.multi
    def open_existing_session_cb(self):
        result = super(PosConfig, self).open_existing_session_cb()

        if self.current_session_id:
            self.current_session_id.can_be_closed = False
        return result



    @api.multi
    def open_session_cb(self):
        result = super(PosConfig, self).open_session_cb()

        self.current_session_id.can_be_closed = False
        return result