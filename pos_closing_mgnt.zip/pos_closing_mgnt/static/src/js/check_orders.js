odoo.define('pos_closing_mgnt.check_orders', function (require) {
    "use strict";



    
    var pos_model = require('point_of_sale.models');
    var PosModelSuper = pos_model.PosModel.prototype;
    var DB = require('point_of_sale.DB');
    var rpc = require('web.rpc');
    var core = require('web.core');
    var chrome = require('point_of_sale.chrome')



    chrome.HeaderButtonWidget.include({
        renderElement: function(){
            var self = this;
            this._super();
            const data = -1;
            // const test = true;
            
            this.$el.click(function(){
                
                function checkOrdersInLocalstorage(){
                    var local_storage = window.localStorage;
                    var keys = [];
                    for (var key in local_storage) keys.push(key)
                    var cle = ""
                    for(var i=0; i<keys.length; i++){
                        if (keys[i].includes('orders') && !keys[i].includes('unpaid')){
                            cle = keys[i];}}
                    var tmp = local_storage[cle];
                    var ordersList = tmp.split('['); 
                    var liste_vide = false
                    if(ordersList.length == 2){
                        liste_vide = true;
                    }

                    else liste_vide = false;
                    
                    return liste_vide;
                }

                if(!checkOrdersInLocalstorage()){// On vérifie si la liste n'est pas vide
                    self.gui.show_popup('error', {
                        'title': _t('Erreur de conformité'),
                        'body': _t('Veuillez vous rassurer que vous navez pas de commande en attente!\n\nSi le problème persiste veuillez contacter votre administrateur!'),
                    });
                }

                else {
                    alert(this.options.order.pos_session_id);
                    // rpc.query({//Appel de la méthode sur le serveur
                    //     model: 'pos.session',
                    //     method: 'set_field_can_be_closed',
                    //     args: [[], this.options.order.pos_session_id],
                    // }).then(function(){});
                } 
                
            });
        },
    });

});