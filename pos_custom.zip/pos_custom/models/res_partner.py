# -*- coding: utf-8 -*-
from odoo import fields, models


class ResPartner(models.Model):

    _inherit = 'res.partner'

    cni = fields.Char(
        string='CNI',
        required=False,
        readonly=False,
        index=False,
        default=None,
        help="Numero de CNI")
