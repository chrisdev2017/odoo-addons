odoo.define('pos_custom.client_list', function (require) {

		"use strict";

		var PosBaseWidget = require('point_of_sale.BaseWidget');
		var screens = require('point_of_sale.screens');
		var pos_model = require('point_of_sale.models');
		var PosModelSuper = pos_model.PosModel.prototype;
		var DB = require('point_of_sale.DB');
		var rpc = require('web.rpc');
		var core = require('web.core');
		var QWeb = core.qweb;

		// var Model = require('web.DataModel');
		// pos_model.load_fields("res.partner", "cni");


		var NewPosDB = DB.include({
			init: function(options){
				this._super(options);
				this.partner_model = {};
			},

			set_cni: function(cni){
				this.partner_model.cni = cni;
				return this.partner_model;
			},

			get_cni: function(){
				return this.partner_model
			},

		});


		pos_model.PosModel = pos_model.PosModel.extend({
				load_server_data: function(){
						var self = this;
						var loaded = PosModelSuper.load_server_data.call(this);
						self.load_cni_data();
						return loaded
				},

				load_cni_data: function(){
					var self = this;
					pos_model.load_models([{
						model: 'res.partner',
						fields: ['cni'],
						loaded: function(self,result){
							for (var i = 0; i < result.length; i++) {
								if(result[i].cni){
									self.db.set_cni(result[i].cni)
									var partners = self.db.get_partners_sorted(1000);
									for (var i = 0; i < partners.length; i++) {
											partners[i].cni = self.db.get_cni().cni
									}
								}
							}

						},
					}], {'after': 'product.product'});
				},

		});


		var RegisterButton = screens.ActionButtonWidget.extend({
		    template: 'RegisterButton',
		    button_click: function(){
		        var self = this;
						self.gui.show_popup('number',{
              title: "Enregistrer la commande",
							value: 2000,
              confirm: function(){
                var value = this.$('.value').text(this.inputbuffer)[0].textContent;
                self.apply_register(value)
              },
              cancel: function(){
                self.gui.back();
              }
            });
		    },
		    apply_register: function(value) {
		        console.log("registred");
		        console.log(value);
		    },
		});

		screens.define_action_button({
		    'name': 'discount',
		    'widget': RegisterButton
		});


		screens.ActionpadWidget.include({

			renderElement: function() {
				var self = this;
        this._super();

				self.$('.pay').click(function(){
						var client = self.pos.get_order().get_client();
						if(!client){
							self.gui.show_popup('error', {
                    'title': _t('Aucun client choisi'),
                    'body': _t('Veuillez choisir un client SVP!')
              });
              return;
						}else{
								self.gui.show_screen('payment');
						}

				});

	    },

	  });


		screens.PaymentScreenWidget.include({

	    validate_order: function(force_validation) { // Confirm payment before validation
	      self = this;
				var client = self.pos.get_order().get_client();
				if(!client){
					self.gui.show_popup('error', {
								'title': _t('Aucun client choisi'),
								'body': _t('Veuillez choisir un client SVP!')
					});
					return;
				}else{
					if (self.order_is_valid(force_validation)) {
							self.finalize_validation();
					}
				}

	    },

	  }) ;


		screens.ClientListScreenWidget.include({

			init: function(parent, options){
	        this._super(parent, options);
	    },

			save_client_details: function(partner) {
        var self = this;

        var fields = {};
        this.$('.client-details-contents .detail').each(function(idx,el){
            fields[el.name] = el.value || false;
        });

        if (!fields.name) {
            this.gui.show_popup('error',_t('A Customer Name Is Required'));
            return;
        }

        if (this.uploaded_picture) {
            fields.image = this.uploaded_picture;
        }

        fields.id           = partner.id || false;
        fields.country_id   = fields.country_id || false;
        fields.cni   = fields.cni || false;

        if (fields.property_product_pricelist) {
            fields.property_product_pricelist = parseInt(fields.property_product_pricelist, 10);
        } else {
            fields.property_product_pricelist = false;
        }
        var contents = this.$(".client-details-contents");
        contents.off("click", ".button.save");


        rpc.query({
                model: 'res.partner',
                method: 'create_from_ui',
                args: [fields],
            })
            .then(function(partner_id){
                self.saved_client_details(partner_id);
            },function(err,ev){
                ev.preventDefault();
                var error_body = _t('Your Internet connection is probably down.');
                if (err.data) {
                    var except = err.data;
                    error_body = except.arguments && except.arguments[0] || except.message || error_body;
                }
                self.gui.show_popup('error',{
                    'title': _t('Error: Could not Save Changes'),
                    'body': error_body,
                });
                contents.on('click','.button.save',function(){ self.save_client_details(partner); });
            });
    	},

		});


});
