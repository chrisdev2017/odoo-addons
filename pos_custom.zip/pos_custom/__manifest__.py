{
    "name": "POS custom",
    "summary": "POS Customization",
    "category": "Wise",
    "version": "0.0.1",
    "author": "Abdou Nasser",
    "support": "abdounasser202@gmail.com",
    "website": "https://formation-odoo.blogspot.com",
    "license": "LGPL-3",
    "depends": ["point_of_sale"],
    "data": [
        "views/res_partner_views.xml",
        "views/pos_custom.xml"
    ],
    'qweb': ['static/src/xml/pos.xml'],
    'demo': [],
    'test': [],
    'installable': True,
    'auto_install': False,
    'application': True,
}
